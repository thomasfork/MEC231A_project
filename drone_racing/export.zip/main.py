import numpy as np
from matplotlib import pyplot as plt
import pdb

from sim import drone_simulator
from track import track as dt

from LMPC import LMPC
from LMPC.local_linearization import PredictiveModel
from LMPC import initControllerParameters as ugo_parameters
from LMPC import PredictiveModel as ugo_model
from LMPC import PredictiveControllers as ugo_controller

from raceline.raceline import GlobalRaceline
import os


def run_LQR_lap(drone, track):
    
    fig = plt.figure(figsize = (14,7))
    ax = fig.gca(projection='3d')
    track.plot_map(ax)
    plt.ion()
    plt.show(block = False)
    fig.canvas.draw()
    fig.canvas.flush_events()
    bg = fig.canvas.copy_from_bbox(fig.bbox)
    
    Q = 1*np.eye(10)
    R = 1*np.eye(3)
    K = drone.LQR(Q,R)
    
    x0 = np.vstack([np.zeros((10,1)), 1])
    x = x0
    s = 0
    s_tar = 10
    itr = 0
    loc = ax.plot(x[0],x[4],x[8], 'ob', markersize = 12)
    
    s_list = []
    e_y_list = []
    e_z_list = []
    e_th_list = []
    e_phi_list = []
    t_list = []
    
    x_list = []
    u_list = []
    
    t = 0
    p = np.array([0,0,0])
    
    while s_tar - 25 < track.track_length:
        global_p, global_th, global_phi  = track.local_to_global_curvillinear(s_tar, 0, 0, 0, 0)
        #print('New Target: %s'%str(global_p))
        x_tar = np.zeros(x0.shape)
        x_tar[0] = global_p[0]
        x_tar[4] = global_p[1]
        x_tar[8] = global_p[2]
        pdb.set_trace()
        last_itr = itr
        while np.linalg.norm(global_p - p) > 10: # s_tar - s > 10:
            u = -K @ (x - x_tar)
            x = drone.A @ x + drone.B @ u
            
            p = np.array([x[0], x[4], x[8]]).squeeze()
            s, e_y, e_z, e_th, e_phi = track.global_to_local_waypoint(p, 0, 0)
            
            t += 0.05
            t_list.append(t)
            
            s_list.append(s)
            e_y_list.append(e_y)
            e_z_list.append(e_z)
            e_th_list.append(e_th)
            e_phi_list.append(e_phi)
            
            x_list.append(x.squeeze())
            u_list.append(u.squeeze())
            
            if itr % 10 == 0:
                fig.canvas.restore_region(bg)
            
            
                loc[0].set_data(x[0],x[4])
                loc[0].set_3d_properties(x[8])
            
                fig.canvas.draw()
                fig.canvas.flush_events()
            itr += 1
            if itr - last_itr > 1000:
                print(s_tar - s)
        s_tar += 15
    
    plt.ioff()
    fig = plt.figure()
    ax = plt.subplot(3,1,1)
    ax.plot(t_list,s_list)
    plt.title('LQR path length vs. time')
    ax = plt.subplot(3,1,2)
    ax.plot(t_list,e_y_list)
    plt.title('LQR lateral error vs. time')
    ax = plt.subplot(3,1,3)
    ax.plot(t_list,e_z_list)
    plt.title('LQR vertical error vs. time')
    plt.show()
    
    x_list = np.array(x_list)
    q_list = np.array(t_list)
    q_list = np.flip(q_list)
    u_list = np.array(u_list)
    
    return x_list, u_list, q_list

def run_LQR_raceline(drone, track, raceline):
    fig = plt.figure(figsize = (14,7))
    ax = fig.gca(projection='3d')
    track.plot_map(ax)
    plt.ion()
    plt.show(block = False)
    fig.canvas.draw()
    fig.canvas.flush_events()
    bg = fig.canvas.copy_from_bbox(fig.bbox)
    
    Q = 1*np.eye(10)
    R = 1*np.eye(3)
    K = drone.LQR(Q,R)
    
    x0 = np.vstack([np.zeros((10,1)), 1])
    x = x0
    s = 0
    s_tar = 10
    itr = 0
    loc = ax.plot(x[0],x[4],x[8], 'ob', markersize = 12)
    
    s_list = []
    e_y_list = []
    e_z_list = []
    e_th_list = []
    e_phi_list = []
    t_list = []
    
    x_list = []
    u_list = []
    
    t = 0
    p = np.array([0,0,0])
    
    while s_tar  < track.track_length:
        x_tar, u_tar, s_tar = raceline.update_target(s) 
        
        
        u = -K @ (x - x_tar) + u_tar
        x = drone.A @ x + drone.B @ u
            
        p = np.array([x[0], x[4], x[8]]).squeeze()
        s, e_y, e_z, e_th, e_phi = track.global_to_local_waypoint(p, 0, 0)
            
        t += 0.05
        t_list.append(t)
            
        s_list.append(s)
        e_y_list.append(e_y)
        e_z_list.append(e_z)
        e_th_list.append(e_th)
        e_phi_list.append(e_phi)
            
        x_list.append(x.squeeze())
        u_list.append(u.squeeze())
            
        if itr % 10 == 0:
            fig.canvas.restore_region(bg)
            
            
            loc[0].set_data(x[0],x[4])
            loc[0].set_3d_properties(x[8])
            
            fig.canvas.draw()
            fig.canvas.flush_events()
        itr += 1
    
    plt.ioff()
    fig = plt.figure()
    ax = plt.subplot(3,1,1)
    ax.plot(t_list,s_list)
    plt.title('LQR raceline path length vs. time')
    ax = plt.subplot(3,1,2)
    ax.plot(t_list,e_y_list)
    plt.title('LQR raceline lateral error vs. time')
    ax = plt.subplot(3,1,3)
    ax.plot(t_list,e_z_list)
    plt.title('LQR raceline vertical error vs. time')
    plt.show()
    
    x_list = np.array(x_list)
    q_list = np.array(t_list)
    q_list = np.flip(q_list)
    u_list = np.array(u_list)
    
    return x_list, u_list, q_list
    
    return

'''def run_LMPC(drone, track, x_data, u_data, q_data):
    N = 20
    num_ss = 50
    
    Q = 1*np.eye(11)
    Q[-1,-1] = 0
    P = Q.copy()
    R = 1*np.eye(3)
    dR = 0 * R
    
    Q_mu = 10 * np.eye(11)
    Q_eps = 10 * np.eye(N)
    b_eps = np.zeros((N,1))
    
    ss_vecs = x_data.T[:,0:num_ss]
    ss_q = np.array([q_data]).T[0:num_ss,:]
    
    Fx = np.eye(11)
    bx_u = 200*np.ones((11,1))
    bx_l = -bx_u.copy()
    
    Fu = np.eye(3)
    bu_u = np.array([[np.pi/4, np.pi/4, 20]]).T
    bu_l = -bu_u.copy()
    
    E = np.ones((11,1))
    
    x0 = np.vstack([np.zeros((10,1)), 1])
    
    lin = PredictiveModel()
    lin.add_trajectory(x_data[:,0:-1], u_data[:,0:-1], x_data[:,1:])
    
    
    
    m = LMPC.MPCUtil(N, 11, 3, num_ss = num_ss)
    
    m.set_model_matrices(drone.A, drone.B, None)
    m.set_x0(x0)
    m.set_state_costs(Q, P, R, dR)
    m.set_slack_costs(Q_mu, Q_eps, b_eps)
    m.set_ss(ss_vecs, ss_q)
    m.build_cost_matrix()
    m.set_state_constraints(Fx, bx_u, bx_l, Fu, bu_u, bu_l, E)
    m.build_constraint_matrix()
    
    pdb.set_trace()
    
    return   '''

def run_ugo_LMPC(drone, track, x_data, u_data, q_data):
    N = 14                                    # Horizon length
    n = 10;   d = 3                            # State and Input dimension
    x0 = np.zeros((n))       # Initial condition
    
    dt = 0.05
    
    vt = 0.8
    
    # add track to drone class for usage by LMPC controller
    drone.map = track
    drone.map.TrackLength = drone.map.track_length
    drone.map.halfWidth = drone.map
    
    # Initialize controller parameters
    mpcParam, ltvmpcParam = ugo_parameters.initMPCParams(n, d, N, vt)
    numSS_it, numSS_Points, Laps, TimeLMPC, QterminalSlack, lmpcParameters = ugo_parameters.initLMPCParams(track, N)
    
    
    
    # Initialize Controller
    lmpcParameters.timeVarying     = True 
    lmpc = ugo_controller.LMPC(numSS_Points, numSS_it, QterminalSlack, lmpcParameters, drone)
    
    lmpc.addTrajectory( x_data, u_data, None)
    
    def run_ugo_LMPC_lap(x0):
        x = x0.copy()
        itr = 0
        done = False
        while not done:
            lmpc.solve(x)
            u = lmpc.uPred[0,:].copy()
            lmpc.addPoint(x, u)
            x = drone.A @ x + drone.B @ u
            
            if itr % 10 == 0:
                fig.canvas.restore_region(bg)
                
                
                loc[0].set_data(x[0],x[4])
                loc[0].set_3d_properties(x[8])
                
                fig.canvas.draw()
                fig.canvas.flush_events()
            itr += 1
        
        
        
    # Run sevaral laps
    for it in range(10):
        # Simulate controller
        x_data, u_data, xF = LMPCsimulator.sim(xS,  lmpc)
        # Add trajectory to controller
        lmpc.addTrajectory( x_data, u_data, None)
        # lmpcpredictiveModel.addTrajectory(np.append(xLMPC,np.array([xS[0]]),0),np.append(uLMPC, np.zeros((1,2)),0))
        #lmpcpredictiveModel.addTrajectory(xLMPC,uLMPC)
        print("Completed lap: ", it, " in ", np.round(lmpc.Qfun[it][0]*dt, 2)," seconds")
    print("===== LMPC terminated")
    
    
    
def main():
    drone = drone_simulator.DroneSim()
    track = dt.DroneTrack()
    track.load_default()
    if os.path.exists('lqr_data.npz'):
        data = np.load('lqr_data.npz')
        x_list = data['x_list']
        u_list = data['u_list']
        q_list = data['q_list']
    else:
        x_list, u_list, q_list = run_LQR_lap(drone, track)
        np.savez('lqr_data.npz', x_list  =x_list, u_list = u_list, q_list = q_list)
    
    '''raceline = GlobalRaceline(x_list, u_list, track, window = 1)
    if os.path.exists('lqr_raceline_data.npz'):
        data = np.load('lqr_raceline_data.npz')
        x_raceline = data['x_list']
        u_raceline = data['u_list']
        q_raceline = data['q_list']
    else:
        x_raceline, u_raceline, q_raceline = run_LQR_raceline(drone, track, raceline)
        np.savez('lqr_raceline_data.npz', x_list  = x_raceline, u_list = u_raceline, q_list = q_raceline)
    
    #run_LMPC(drone, track, x_list, u_list, q_list)
    run_ugo_LMPC(drone,track, x_list, u_list, q_list)'''
    

if __name__ == '__main__':
    main()
